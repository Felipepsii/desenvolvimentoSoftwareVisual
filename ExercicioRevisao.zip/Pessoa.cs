namespace Sub;

public class Pessoa
{
	public string? nome { get; set; }
	public string? contrario { get; set; }
    public DateTime? nascimento { get; set; }
    public string? signo { get; set; }
}
